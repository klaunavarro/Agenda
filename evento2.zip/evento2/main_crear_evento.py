#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller1
from PySide import QtGui, QtCore
from Crear_evento import Ui_Crear_evento

class Evento_crear(QtGui.QDialog):

    def __init__(self):
        super(Evento_crear, self).__init__()
        self.ui = Ui_Crear_evento()
        self.ui.setupUi(self)
        self.cargar_calendarios()
        self.listeners()
        self.show()

        
    def listeners(self):
		    
        self.ui.buttonBox.clicked.connect(self.crear_evento)
        self.ui.buttonBox.clicked.connect(self.cancel)
    
    def cargar_calendarios(self):
        calendarios = controller1.obtener_cal()
        for cal in calendarios:
            self.ui.comboBox.addItem(cal["nombre"], cal["id_calendario"])
    
        
    def crear_evento(self):
		
		calendario = str( self.ui.comboBox.itemData(self.ui.comboBox.currentIndex()))
		
		detalle = self.ui.lineEdit.text()
		desde = self.ui.dateTimeEdit.dateTime()
		hasta = self.ui.dateTimeEdit_2.dateTime()
		#obtengo el año , mes ,dia, hora, minuto, segundos de mis dateTime
		ano=self.ui.dateTimeEdit.date().year()
		mes=self.ui.dateTimeEdit.date().month()
		dia=self.ui.dateTimeEdit.date().day()
		hora=self.ui.dateTimeEdit.time().hour()
		minuto=self.ui.dateTimeEdit.time().minute()
		segundo=self.ui.dateTimeEdit.time().second()
		ano2=self.ui.dateTimeEdit_2.date().year()
		mes2=self.ui.dateTimeEdit_2.date().month()
		dia2=self.ui.dateTimeEdit_2.date().day()
		hora2=self.ui.dateTimeEdit_2.time().hour()
		minuto2=self.ui.dateTimeEdit_2.time().minute()
		segundo2=self.ui.dateTimeEdit_2.time().second()
		lugar = self.ui.lineEdit_2.text()
		participantes = self.ui.lineEdit_3.text()
		fecha=dia,mes,ano,hora,minuto,segundo
		fecha2=dia2,mes2,ano2,hora2,minuto2,segundo2
		# Aca concateno las fechas y las horas que fueron guardadas arriba por separado
		
		#fecha_i=str(fecha[2])+ "-" +str(fecha[1])+ "-"+ str(fecha[0]) + "  " +str(fecha[3])+ ":" +str(fecha[4])+ ":"+ str(fecha[5])
		#fecha_f=str(fecha[2])+ "-" +str(fecha2[1])+ "-"+ str(fecha2[0]) + "  " +str(fecha2[3])+ ":" +str(fecha2[4])+ ":"+ str(fecha2[5])
		#crear_evento = controller1.crear_evento(detalle,fecha_i,fecha_f,lugar,participantes,calendario)
		
		if (len(str(dia)) == 1):
			fecha_i=str(fecha[2])+ "-" +"0"+str(fecha[1])+ "-"+ "0"+ str(fecha[0]) + " " +"0"+str(fecha[3])+ ":" +"0"+str(fecha[4])+ ":"+"0"+ str(fecha[5])
			fecha_f=str(fecha[2])+ "-" +"0"+str(fecha2[1])+ "-"+ "0"+str(fecha2[0]) + "  " +"0"+str(fecha2[3])+ ":" +"0"+str(fecha2[4])+ ":"+"0"+str(fecha2[5])
			crear_evento = controller1.crear_evento(detalle,fecha_i,fecha_f,lugar,participantes,calendario)
		else:
			fecha_i=str(fecha[2])+ "-" +str(fecha[1])+ "-"+str(fecha[0]) + " " +str(fecha[3])+ ":" +str(fecha[4])+ ":"+ str(fecha[5])
			fecha_f=str(fecha[2])+ "-" +str(fecha2[1])+ "-"+ str(fecha2[0]) + "  " +str(fecha2[3])+ ":" +str(fecha2[4])+ ":"+ str(fecha2[5])
			crear_evento = controller1.crear_evento(detalle,fecha_i,fecha_f,lugar,participantes,calendario)
		#print fecha_i	
		#print(calendario)
		#print (fecha_f)
	
      
    def cancel(self):
        self.reject()
   



