# -*- coding: utf-8 -*-


from PySide import QtCore, QtGui



class Ui_Evento(object):
    
    def setupUi(self, Evento):
        Evento.setObjectName("Evento")
        Evento.resize(720, 460)
        
        self.Eliminar = QtGui.QPushButton(Evento)
        self.Eliminar.setGeometry(QtCore.QRect(590, 160, 100, 30))
        self.Eliminar.setObjectName("Eliminar")
        
        self.Editar = QtGui.QPushButton(Evento)
        self.Editar.setGeometry(QtCore.QRect(590, 120, 100, 30))
        self.Editar.setObjectName("Editar")
        
        self.Crear = QtGui.QPushButton(Evento)
        self.Crear.setGeometry(QtCore.QRect(590, 80, 100, 30))
        self.Crear.setObjectName("Crear")
        
        self.Salir = QtGui.QPushButton(Evento)
        self.Salir.setGeometry(QtCore.QRect(590, 350, 100, 30))
        self.Salir.setObjectName("Salir")
        
        self.Btn_search = QtGui.QPushButton(Evento)
        self.Btn_search.setGeometry(QtCore.QRect(310, 30, 100, 30))
        self.Btn_search.setObjectName("Btn_search")
        
        self.Search_box = QtGui.QLineEdit(Evento)
        self.Search_box.setGeometry(QtCore.QRect(10, 30, 290, 30))
        self.Search_box.setStyleSheet("")
        self.Search_box.setObjectName("Search_box")
        
        self.Btn_menu_1 = QtGui.QPushButton(Evento)
        self.Btn_menu_1.setGeometry(QtCore.QRect(590, 200, 98, 27))
        self.Btn_menu_1.setObjectName("Btn_menu_1")
        
        self.tableView = QtGui.QTableView(Evento)
        self.tableView.setGeometry(QtCore.QRect(10, 80, 561, 341))
        self.tableView.setObjectName("tableView")

        self.retranslateUi(Evento)
        QtCore.QMetaObject.connectSlotsByName(Evento)


    def retranslateUi(self, Evento):
        Evento.setWindowTitle(QtGui.QApplication.translate("Evento", "Eventos", None, QtGui.QApplication.UnicodeUTF8))
        self.Eliminar.setText(QtGui.QApplication.translate("Evento", "Eliminar", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("Evento", "Editar", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("Evento", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.Salir.setText(QtGui.QApplication.translate("Evento", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.Btn_search.setText(QtGui.QApplication.translate("Evento", "Buscar", None, QtGui.QApplication.UnicodeUTF8))
        self.Search_box.setText(QtGui.QApplication.translate("Evento", "Buscar evento por Detalle", None, QtGui.QApplication.UnicodeUTF8))
        self.Search_box.setPlaceholderText(QtGui.QApplication.translate("Evento", "Buscar Evento aquí por Detalle", None, QtGui.QApplication.UnicodeUTF8))
        self.Btn_menu_1.setText(QtGui.QApplication.translate("Evento", "Calendario", None, QtGui.QApplication.UnicodeUTF8))



