# -*- coding: utf-8 -*-



from PySide import QtCore, QtGui

class Ui_Crear_evento(object):
    def setupUi(self, Evento):
        Evento.setObjectName("Evento")
        Evento.resize(444, 436)
        
        self.comboBox = QtGui.QComboBox(Evento)
        self.comboBox.setGeometry(QtCore.QRect(170, 30, 141, 27))
        self.comboBox.setObjectName("comboBox")
        
        self.lineEdit = QtGui.QLineEdit(Evento)
        self.lineEdit.setGeometry(QtCore.QRect(120, 90, 291, 27))
        self.lineEdit.setObjectName("lineEdit")
        
        self.label = QtGui.QLabel(Evento)
        self.label.setGeometry(QtCore.QRect(70, 30, 91, 20))
        self.label.setObjectName("label")
        
        self.label_2 = QtGui.QLabel(Evento)
        self.label_2.setGeometry(QtCore.QRect(40, 90, 66, 17))
        self.label_2.setObjectName("label_2")
        
        self.label_3 = QtGui.QLabel(Evento)
        self.label_3.setGeometry(QtCore.QRect(30, 150, 66, 17))
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        
        self.label_4 = QtGui.QLabel(Evento)
        self.label_4.setGeometry(QtCore.QRect(40, 160, 51, 17))
        self.label_4.setObjectName("label_4")
        
        self.label_8 = QtGui.QLabel(Evento)
        self.label_8.setGeometry(QtCore.QRect(30, 220, 66, 17))
        self.label_8.setText("")
        self.label_8.setObjectName("label_8")
        
        self.label_9 = QtGui.QLabel(Evento)
        self.label_9.setGeometry(QtCore.QRect(40, 220, 61, 17))
        self.label_9.setObjectName("label_9")
        
        self.lineEdit_2 = QtGui.QLineEdit(Evento)
        self.lineEdit_2.setGeometry(QtCore.QRect(120, 280, 291, 27))
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.lineEdit_3 = QtGui.QLineEdit(Evento)
        self.lineEdit_3.setGeometry(QtCore.QRect(120, 330, 291, 27))
        self.lineEdit_3.setObjectName("lineEdit_3")
        
        self.label_13 = QtGui.QLabel(Evento)
        self.label_13.setGeometry(QtCore.QRect(40, 280, 66, 21))
        self.label_13.setObjectName("label_13")
        
        self.label_14 = QtGui.QLabel(Evento)
        self.label_14.setGeometry(QtCore.QRect(10, 330, 101, 17))
        self.label_14.setObjectName("label_14")
        
        self.dateTimeEdit = QtGui.QDateTimeEdit(Evento)
        self.dateTimeEdit.setGeometry(QtCore.QRect(120, 160, 194, 27))
        self.dateTimeEdit.setObjectName("dateTimeEdit")
        self.dateTimeEdit_2 = QtGui.QDateTimeEdit(Evento)
        self.dateTimeEdit_2.setGeometry(QtCore.QRect(120, 220, 194, 27))
        self.dateTimeEdit_2.setObjectName("dateTimeEdit_2")
        
        self.boton = QtGui.QPushButton(Evento)
        self.boton.setGeometry(QtCore.QRect(100, 380, 100, 27))
        self.boton.setObjectName("Crear")
        
        self.boton_2 = QtGui.QPushButton(Evento)
        self.boton_2.setGeometry(QtCore.QRect(250, 380, 100, 27))
        self.boton_2.setObjectName("Crear_2")
        
        self.retranslateUi(Evento)
        QtCore.QMetaObject.connectSlotsByName(Evento)


    def retranslateUi(self, Evento):
        Evento.setWindowTitle(QtGui.QApplication.translate("Evento", "Eventoes", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Evento", "Calendario", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Evento", "Detalles :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Evento", "Desde:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_9.setText(QtGui.QApplication.translate("Evento", "Hasta :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_13.setText(QtGui.QApplication.translate("Evento", "Lugar    :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_14.setText(QtGui.QApplication.translate("Evento", "Participantes :", None, QtGui.QApplication.UnicodeUTF8))
        self.dateTimeEdit.setDisplayFormat(QtGui.QApplication.translate("Evento", "dd-MM-yyyy HH:mm:ss", None, QtGui.QApplication.UnicodeUTF8))
        self.dateTimeEdit_2.setDisplayFormat(QtGui.QApplication.translate("Evento", "dd-MM-yyyy HH:mm:ss", None, QtGui.QApplication.UnicodeUTF8))
        self.boton.setText(QtGui.QApplication.translate("calendario", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.boton_2.setText(QtGui.QApplication.translate("calendario", "Salir", None, QtGui.QApplication.UnicodeUTF8))

   
