#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con


def obtener_eventos():
    con = conectar()
    c = con.cursor()
    query = """SELECT a.id_evento,a.detalle, a.fecha_desde, a.fecha_hasta ,b.nombre,a.detalle, a.lugar, a .participantes  
              FROM eventos a , calendarios b WHERE b.id_calendario = a.fk_id_calendario"""
    d = c.execute(query)
    eventos = d.fetchall()
    con.close()
    return eventos
    
    
def buscar_eventos(word):
	con = conectar()
	c = con.cursor()
	query = """SELECT a.id_evento, a.fecha_desde, a.fecha_hasta, b.nombre, a.detalle, a.lugar,a.participantes
			FROM eventos a ,calendarios b WHERE a.fk_id_calendario = b.id_calendario
            AND (a.fecha_desde LIKE '%'||?||'%' OR a.fecha_hasta LIKE '%'||?||'%' OR b.nombre LIKE '%'||?||'%' OR a.detalle LIKE '%'||?||'%'OR a.lugar LIKE '%'||?||'%' OR a.participantes LIKE '%'||?||'%' )"""
	d = c.execute(query, [word,word,word,word,word,word])
	busqueda = d.fetchall()
	con.close()
	return busqueda


def obtener_cal():
    con = conectar()
    c = con.cursor()
    query = "SELECT * FROM calendarios "
    d= c.execute(query)
    cal = d.fetchall()
    con.close()
    return cal

    
def crear_evento(detalle,desde, hasta,lugar,participantes,calendario):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [None,detalle,desde,hasta,lugar,participantes,calendario]
	query = "INSERT INTO eventos (id_evento, detalle ,fecha_desde ,fecha_hasta ,lugar ,participantes ,fk_id_calendario) VALUES (?,?,?,?,?,?,?)"
	try:
		d = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print ("Error:"), e.args[0]
		con.close()
	return exito


def delete(id_evento):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM eventos WHERE id_evento = ?"
    try:
        d = c.execute(query, [id_evento])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print "Error:", e.args[0]
    con.close()
    return exito

    
def obtener(ev):
    con = conectar()
    c = con.cursor()
    query = """select a.detalle, a.fecha_desde, a.fecha_hasta ,b.nombre,a.detalle, a.lugar, a .participantes  
              from eventos a , calendarios b where b.id_calendario = a.fk_id_calendario AND a.fecha_desde = ?"""
    d = c.execute(query , [ev])
    eventos = d.fetchall()
    con.close()
    return eventos


def obtener_id(nombre):
    con = conectar()
    c = con.cursor()
    query = "SELECT id_evento FROM eventos WHERE fecha_desde= ?"
    d = c.execute(query,[nombre])
    obtener_id = d.fetchall()
    con.close()
    return obtener_id
    
  
def editar_evento(detalle, desde,hasta,lugar,participantes,fk_id_calendario,obtener_id):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [detalle, desde,hasta,lugar,participantes,fk_id_calendario,obtener_id]
	query = """UPDATE  eventos SET detalle = ?, fecha_desde = ?, fecha_hasta = ?,lugar = ?,
	           participantes = ?,fk_id_calendario = ?  WHERE id_evento = ?"""
	try:
		resultado = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print "Error:", e.args[0]
	con.close()
	return exito

