#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
import main_editar_calendario
import main_crear_calendario
from PySide import QtGui, QtCore
from editar_calendario import Ui_Calendario_editar

class Calendario_editar(QtGui.QDialog):

    def __init__(self, calendario=None):
        super(Calendario_editar, self).__init__()
        self.ui = Ui_Calendario_editar()
        self.ui.setupUi(self)
        self.show()       
        self.calendario = calendario        
        self.ui.lineEdit.setText(calendario)
        #Accion de los botones
        self.ui.Crear.clicked.connect(self.editar)
        self.ui.Crear_2.clicked.connect(self.cancel)

    def editar(self):
        
        id_cal = controller.obtener_id(self.calendario)
        for id_ca in id_cal:
            id_ = id_ca[0]
            id__ = id_
            # saco el valor del linedit
            nombre = self.ui.lineEdit.text()
            if nombre:
				n=controller.obtener_calendario(str(nombre))
				if n:
					self.errorMessageDialog = QtGui.QErrorMessage(self)
					self.errorMessageDialog.showMessage("El calendario ya existe")
                
				else:
					resultado = controller.editar_cal(id__, nombre)
					self.errorMessageDialog = QtGui.QErrorMessage(self)
					self.errorMessageDialog.showMessage("El calendario se ha editado correctamente")
            else:
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("Debe ingresar algo")
                return False
           
			
    def cancel(self):
        self.reject()
		
		
		
		
