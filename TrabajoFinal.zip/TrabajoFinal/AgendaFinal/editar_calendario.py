# -*- coding: utf-8 -*-


from PySide import QtCore, QtGui


class Ui_Calendario_editar(object):
	
    def setupUi(self, Calendario):
        Calendario.setObjectName("Calendario")
        Calendario.resize(343, 111)
        self.Crear = QtGui.QPushButton(Calendario)
        self.Crear.setGeometry(QtCore.QRect(90, 70, 100, 30))
        self.Crear.setObjectName("Crear")
        
        self.Crear_2 = QtGui.QPushButton(Calendario)
        self.Crear_2.setGeometry(QtCore.QRect(230, 70, 100, 30))
        self.Crear_2.setObjectName("Crear_2")
        
        self.lineEdit = QtGui.QLineEdit(Calendario)
        self.lineEdit.setGeometry(QtCore.QRect(90, 30, 241, 27))
        self.lineEdit.setObjectName("lineEdit")
        
        self.label = QtGui.QLabel(Calendario)
        self.label.setGeometry(QtCore.QRect(10, 30, 66, 17))
        self.label.setObjectName("label")

        self.retranslateUi(Calendario)
        QtCore.QMetaObject.connectSlotsByName(Calendario)


    def retranslateUi(self, Calendario):
        Calendario.setWindowTitle(QtGui.QApplication.translate("Calendario", "Calendarioes", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("Calendario", "Guardar", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear_2.setText(QtGui.QApplication.translate("Calendario", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Calendario", "Nombre :", None, QtGui.QApplication.UnicodeUTF8))


