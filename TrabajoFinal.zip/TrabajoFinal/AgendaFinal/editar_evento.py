# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui

class Ui_editar_evento(object):
    
    def setupUi(self, Evento):
		
        Evento.setObjectName("Evento")
        Evento.resize(444, 405)
        
        self.comboBox = QtGui.QComboBox(Evento)
        self.comboBox.setGeometry(QtCore.QRect(260, 40, 141, 27))
        self.comboBox.setObjectName("comboBox")
        
        self.lineEdit = QtGui.QLineEdit(Evento)
        self.lineEdit.setGeometry(QtCore.QRect(110, 40, 131, 27))
        self.lineEdit.setObjectName("lineEdit")
        
        self.label = QtGui.QLabel(Evento)
        self.label.setGeometry(QtCore.QRect(20, 30, 91, 20))
        self.label.setObjectName("label")
        
        self.label_3 = QtGui.QLabel(Evento)
        self.label_3.setGeometry(QtCore.QRect(30, 150, 66, 17))
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        
        self.label_4 = QtGui.QLabel(Evento)
        self.label_4.setGeometry(QtCore.QRect(20, 140, 51, 17))
        self.label_4.setObjectName("label_4")
        
        self.label_8 = QtGui.QLabel(Evento)
        self.label_8.setGeometry(QtCore.QRect(30, 220, 66, 17))
        self.label_8.setText("")
        self.label_8.setObjectName("label_8")
        
        self.label_9 = QtGui.QLabel(Evento)
        self.label_9.setGeometry(QtCore.QRect(20, 190, 61, 17))
        self.label_9.setObjectName("label_9")
        
        self.lineEdit_2 = QtGui.QLineEdit(Evento)
        self.lineEdit_2.setGeometry(QtCore.QRect(110, 240, 291, 27))
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.lineEdit_3 = QtGui.QLineEdit(Evento)
        self.lineEdit_3.setGeometry(QtCore.QRect(110, 290, 291, 27))
        self.lineEdit_3.setObjectName("lineEdit_3")
        
        self.label_13 = QtGui.QLabel(Evento)
        self.label_13.setGeometry(QtCore.QRect(20, 240, 66, 21))
        self.label_13.setObjectName("label_13")
        
        self.label_14 = QtGui.QLabel(Evento)
        self.label_14.setGeometry(QtCore.QRect(10, 290, 101, 17))
        self.label_14.setObjectName("label_14")
        #Aca se crearon datetimeedit para trabajar con las fechas y horas
        #Aca de deben cambiar si se quiere editar y no en el lineedit
        self.dateTimeEdit = QtGui.QDateTimeEdit(Evento)
        self.dateTimeEdit.setGeometry(QtCore.QRect(250, 140, 170, 27))
        self.dateTimeEdit.setObjectName("dateTimeEdit")
        self.dateTimeEdit_2 = QtGui.QDateTimeEdit(Evento)
        self.dateTimeEdit_2.setGeometry(QtCore.QRect(250, 190, 170, 27))
        self.dateTimeEdit_2.setObjectName("dateTimeEdit_2")
        
        self.lineEdit_4 = QtGui.QLineEdit(Evento)
        self.lineEdit_4.setGeometry(QtCore.QRect(110, 90, 291, 27))
        self.lineEdit_4.setObjectName("lineEdit_4")
        
        self.label_15 = QtGui.QLabel(Evento)
        self.label_15.setGeometry(QtCore.QRect(20, 80, 66, 21))
        self.label_15.setObjectName("label_15")
        
        self.lineEdit_5 = QtGui.QLineEdit(Evento)
        self.lineEdit_5.setGeometry(QtCore.QRect(110, 140, 140, 27))
        self.lineEdit_5.setObjectName("lineEdit_5")
        
        self.lineEdit_6 = QtGui.QLineEdit(Evento)
        self.lineEdit_6.setGeometry(QtCore.QRect(110, 190, 140, 27))
        self.lineEdit_6.setObjectName("lineEdit_6")
        
        self.boton = QtGui.QPushButton(Evento)
        self.boton.setGeometry(QtCore.QRect(100, 350, 100, 27))
        self.boton.setObjectName("Crear")
        
        self.boton_2 = QtGui.QPushButton(Evento)
        self.boton_2.setGeometry(QtCore.QRect(250, 350, 100, 27))
        self.boton_2.setObjectName("Crear_2")

        self.retranslateUi(Evento)
        QtCore.QMetaObject.connectSlotsByName(Evento)


    def retranslateUi(self, Evento):
        Evento.setWindowTitle(QtGui.QApplication.translate("Evento", "Eventos", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Evento", "Calendario", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Evento", "Desde:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_9.setText(QtGui.QApplication.translate("Evento", "Hasta :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_13.setText(QtGui.QApplication.translate("Evento", "Lugar    :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_14.setText(QtGui.QApplication.translate("Evento", "Participantes :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_15.setText(QtGui.QApplication.translate("Evento", "Detalles    :", None, QtGui.QApplication.UnicodeUTF8))
        self.dateTimeEdit.setDisplayFormat(QtGui.QApplication.translate("Evento", "dd-MM-yyyy HH:mm:ss", None, QtGui.QApplication.UnicodeUTF8))
        self.dateTimeEdit_2.setDisplayFormat(QtGui.QApplication.translate("Evento", "dd-MM-yyyy HH:mm:ss", None, QtGui.QApplication.UnicodeUTF8))
        self.boton.setText(QtGui.QApplication.translate("Evento", "Aceptar", None, QtGui.QApplication.UnicodeUTF8))
        self.boton_2.setText(QtGui.QApplication.translate("Evento", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        


