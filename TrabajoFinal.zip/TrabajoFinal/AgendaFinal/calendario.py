# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui

class Ui_Calendario(object):
    def setupUi(self, Calendario):
        Calendario.setObjectName("Calendario")
        Calendario.resize(394, 387)
        #Creacion del boton eliminar
        self.Eliminar = QtGui.QPushButton(Calendario)
        self.Eliminar.setGeometry(QtCore.QRect(270, 100, 100, 30))
        self.Eliminar.setObjectName("Eliminar")
        #Creacion del boton editar
        self.Editar = QtGui.QPushButton(Calendario)
        self.Editar.setGeometry(QtCore.QRect(270, 60, 100, 30))
        self.Editar.setObjectName("Editar")
        #Creacion del boton Crear
        self.Crear = QtGui.QPushButton(Calendario)
        self.Crear.setGeometry(QtCore.QRect(270, 20, 100, 30))
        self.Crear.setObjectName("Crear")
        
        self.tableView = QtGui.QTableView(Calendario)
        self.tableView.setGeometry(QtCore.QRect(20, 20, 231, 341))
        self.tableView.setObjectName("tableView")
        
        self.Crear_2 = QtGui.QPushButton(Calendario)
        self.Crear_2.setGeometry(QtCore.QRect(270, 330, 100, 30))
        self.Crear_2.setObjectName("Crear_2")

        self.retranslateUi(Calendario)
        QtCore.QMetaObject.connectSlotsByName(Calendario)


    def retranslateUi(self, Calendario):
        Calendario.setWindowTitle(QtGui.QApplication.translate("Calendario", "Calendarioes", None, QtGui.QApplication.UnicodeUTF8))
        self.Eliminar.setText(QtGui.QApplication.translate("Calendario", "Eliminar", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("Calendario", "Editar", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("Calendario", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear_2.setText(QtGui.QApplication.translate("Calendario", "Salir", None, QtGui.QApplication.UnicodeUTF8))



