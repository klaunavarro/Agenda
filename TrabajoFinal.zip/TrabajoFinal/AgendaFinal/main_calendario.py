#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import main_editar_calendario
import main_crear_calendario
import main_evento
import controller
import controller1
from calendario import Ui_Calendario

class Evento(QtGui.QDialog):

    def __init__(self):
        super(Evento, self).__init__()
        self.ui = Ui_Calendario()
        self.ui.setupUi(self)
        self.set_listeners()
        self.cargar_calendario()
        self.show()
       
    def set_listeners(self):
		
        self.ui.Crear.clicked.connect(self.show_add)
        self.ui.Crear_2.clicked.connect(self.cancel)
        self.ui.Eliminar.clicked.connect(self.eliminar_calendario)
        self.ui.Editar.clicked.connect(self.editar_calendario)
			
    def edit(self):
        
        form = main_crear_calendario.Calendario_crear()
        form.exec_()

    def create(self):

        form2 = main_editar_calendario.Calendario_editar()
        form2.exec_()
         
    def show_add(self):
        Crear_calendario = main_crear_calendario.Calendario_crear()
        Crear_calendario.rejected.connect(self.cargar_calendario)
        Crear_calendario.exec_()
		  		
    def cancel(self):
        self.reject()
        
    def cargar_calendario(self, calendarios = None):
        if calendarios is None:
            calendarios = controller.obtener_calendarios()
         	
        #Creamos el modelo asociado a la tabla
        self.model = QtGui.QStandardItemModel(len(calendarios),1)
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Nombre"))
        
        r = 0
        for row in calendarios:
            index = self.model.index(r, 0, QtCore.QModelIndex());
            self.model.setData(index, row['id_calendario'])
            index = self.model.index(r, 1, QtCore.QModelIndex());
            self.model.setData(index, row['Nombre'])
            r = r+1

        self.ui.tableView.setModel(self.model)
        # Con el hidecolumn hago que no me muestre el id_calendario al cargar la grilla
        self.ui.tableView.hideColumn(0)
        self.ui.tableView.setColumnWidth(0,205)
        
    def editar_calendario(self):
        
        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
            return False
        else:
            calendario = model.index(index.row(), 1, QtCore.QModelIndex()).data()
            Editar_calendario = main_editar_calendario.Calendario_editar(calendario)
            Editar_calendario.rejected.connect(self.cargar_calendario)
            Editar_calendario.exec_()
						
    def eliminar_calendario(self):

        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
            return False
        else:
            self.cargar_calendario()
            msgBox = QtGui.QMessageBox()
            msgBox.setText("El registro fue eliminado.")
            msgBox.setInformativeText("Desea guardar los cambios?")
            msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Discard | QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(QtGui.QMessageBox.Save)
            msgBox.exec_()
            id_calendario = str(model.index(index.row(), 0, QtCore.QModelIndex()).data())
            eliminar_eventos = controller.delete_calendario(str(id_calendario))
            if eliminar_eventos:
                eliminar_eventos = controller.delete(str(id_calendario))
                self.cargar_calendario()
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("Se ha eliminado el calendario")
            else:
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("No se ha podido eliminar registro")

