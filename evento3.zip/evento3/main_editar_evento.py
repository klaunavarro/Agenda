#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller1
from PySide import QtGui, QtCore
from Editar_evento import Ui_editar_evento

class Evento_editar(QtGui.QDialog):

    def __init__(self, evento = None):
        super(Evento_editar, self).__init__()
        self.ui = Ui_editar_evento()
        self.ui.setupUi(self)
        self.cargar_calendarios()
        self.listeners()
        self.show()
        
        self.evento = evento
        c = controller1.obtener(evento)
        #print evento
        for dato in c:
			id_cale = c[0]
			self.ui.lineEdit.setText(dato[3])
			self.ui.lineEdit_2.setText(dato[5])
			self.ui.lineEdit_3.setText(dato[6])
			self.ui.lineEdit_4.setText(dato[4])
			self.ui.lineEdit_5.setText(dato[1])
			self.ui.lineEdit_6.setText(dato[2])
		
       
        
    def listeners(self):
		self.ui.buttonBox.clicked.connect(self.editar_evento)
		self.ui.buttonBox.clicked.connect(self.cancel)   

    def cargar_calendarios(self):
		calendarios = controller1.obtener_cal()
		for cal in calendarios:
			self.ui.comboBox.addItem(cal["nombre"], cal["id_calendario"])
			
    def cancel(self):
		self.reject() 
		
    def editar_evento(self):
		
		
		id_cal = controller1.obtener_id(self.evento)
		
		for id_ca in id_cal:
			id_ = id_ca[0]
			
		id__ = id_
		#print id__
		
		calendario =str(self.ui.comboBox.itemData(self.ui.comboBox.currentIndex()))
		
		detalle = self.ui.lineEdit_4.text()
		
		desde = self.ui.dateTimeEdit.dateTime()
		 
		hasta = self.ui.dateTimeEdit_2.dateTime()
		#Aca tomo los valores por separado de mis dateTimeEdit y al final concateno para poder trabajarlos como string
		ano=self.ui.dateTimeEdit.date().year()
		mes=self.ui.dateTimeEdit.date().month()
		dia=self.ui.dateTimeEdit.date().day()
		hora=self.ui.dateTimeEdit.time().hour()
		minuto=self.ui.dateTimeEdit.time().minute()
		segundo=self.ui.dateTimeEdit.time().second()
		ano2=self.ui.dateTimeEdit_2.date().year()
		mes2=self.ui.dateTimeEdit_2.date().month()
		dia2=self.ui.dateTimeEdit_2.date().day()
		hora2=self.ui.dateTimeEdit_2.time().hour()
		minuto2=self.ui.dateTimeEdit_2.time().minute()
		segundo2=self.ui.dateTimeEdit_2.time().second()
		lugar = self.ui.lineEdit_2.text()
		
		participantes = self.ui.lineEdit_3.text()
		
		fecha=dia,mes,ano,hora,minuto,segundo
		fecha2=dia2,mes2,ano2,hora2,minuto2,segundo2
		
		# Aca concateno las fechas y las horas que fueron guardadas arriba por separado
		fecha_i=str(fecha[2])+ "-" +str(fecha[1])+ "-"+ str(fecha[0]) + "  " +str(fecha[3])+ ":" +str(fecha[4])+ ":"+ str(fecha[5])
		fecha_f=str(fecha[2])+ "-" +str(fecha2[1])+ "-"+ str(fecha2[0]) + "  " +str(fecha2[3])+ ":" +str(fecha2[4])+ ":"+ str(fecha2[5])
		
		
		salida = controller1.editar_evento(detalle,fecha_i,fecha_f,lugar,participantes,str(calendario),str(id__))
		 
		
		if salida:
			self.reject()
		else:
			self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
			self.ui.errorMessageDialog.showMessage("Hubo un problema al intentar editar el producto")

           
   

