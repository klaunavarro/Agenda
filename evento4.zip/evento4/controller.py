#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con


def obtener_calendarios():
    con = conectar()
    c = con.cursor()
    query = "SELECT id_calendario,nombre FROM calendarios "
    d = c.execute(query)
    calendario = d.fetchall()
    con.close()
    return calendario

def crear_calendario(nombre):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [None,nombre]
	query = "INSERT INTO calendarios (id_calendario,nombre) VALUES (?,?)"
	try:
		d = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print "Error:", e.args[0]
		con.close()
	return exito
	
def obtener_id(nombre):
    con = conectar()
    c = con.cursor()
    query = "SELECT id_calendario FROM calendarios WHERE nombre=?"
    d = c.execute(query,[nombre])
    obtener_id = d.fetchall()
    con.close()
    return obtener_id

def editar_cal(obtener_id,nombre):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [nombre, obtener_id]
	query = """UPDATE  calendarios SET nombre = ? WHERE id_calendario = ?"""
	try:
		d = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print "Error:", e.args[0]
	con.close()
	return exito
	
	
	
def obtener_calendario(nombre):
	con = conectar()
	c = con.cursor()
	query= "SELECT * FROM calendarios WHERE nombre = ?"
	d = c.execute(query, [nombre])
	cal = d.fetchone()
	con.close
	return cal
	
def delete(id_categoria):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM eventos WHERE fk_id_calendario = ?"
    try:
        resultado = c.execute(query, [id_categoria])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito

def delete_calendario(id_catego):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM calendarios WHERE id_calendario = ?"
    try:
        resultado = c.execute(query, [id_catego])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito	

