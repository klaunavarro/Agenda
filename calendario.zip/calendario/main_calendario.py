#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import main_editar_calendario
import main_crear_calendario
import controller
from calendario import Ui_Calendario

class Evento(QtGui.QDialog):

    def __init__(self):
        super(Evento, self).__init__()
        self.ui = Ui_Calendario()
        self.ui.setupUi(self)
        self.set_listeners()
        self.cargar_calendario()
        self.show()

    def set_listeners(self):
        self.ui.Crear.clicked.connect(self.edit)
        #self.ui.Eliminar.clicked.connect(self.delete)
        self.ui.Editar.clicked.connect(self.create)
		
    def edit(self):
        form = main_crear_calendario.Calendario_crear()
        form.exec_()

    def create(self):
        form2 = main_editar_calendario.Calendario_editar()
        form2.exec_()
        
        
    def cargar_calendario(self, calendarios = None):

        if calendarios is None:
         	calendarios = controller.obtener_calendarios()
         	
        #Creamos el modelo asociado a la tabla
        self.model = QtGui.QStandardItemModel(len(calendarios),1)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Nombre"))
        
        r = 0
        for row in calendarios:
            index = self.model.index(r, 0, QtCore.QModelIndex());
            self.model.setData(index, row['Nombre'])
            r = r+1

        self.ui.tableView.setModel(self.model)

        self.ui.tableView.setColumnWidth(0,205)
        

   
def run():
    app = QtGui.QApplication(sys.argv)
    ma = Evento()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run()
