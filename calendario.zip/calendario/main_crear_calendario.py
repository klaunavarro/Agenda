#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
from Crear_calendario import Ui_crear_calendario

class Calendario_crear(QtGui.QDialog):

    def __init__(self):
        super(Calendario_crear, self).__init__()
        self.ui = Ui_crear_calendario()
        self.ui.setupUi(self)
        #self.set_listeners()
        self.show()

        
   

