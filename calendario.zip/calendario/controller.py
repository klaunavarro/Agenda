#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con


def obtener_calendarios():
    con = conectar()
    c = con.cursor()
    query = "SELECT nombre FROM calendarios GROUP BY nombre"
    resultado = c.execute(query)
    calendario = resultado.fetchall()
    con.close()
    return calendario


