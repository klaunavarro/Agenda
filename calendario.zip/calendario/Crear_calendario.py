# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui

class Ui_crear_calendario(object):
    def setupUi(self, calendario):
        calendario.setObjectName("calendario")
        calendario.resize(343, 111)
        self.Crear = QtGui.QPushButton(calendario)
        self.Crear.setGeometry(QtCore.QRect(90, 70, 100, 30))
        self.Crear.setObjectName("Crear")
        self.Crear_2 = QtGui.QPushButton(calendario)
        self.Crear_2.setGeometry(QtCore.QRect(230, 70, 100, 30))
        self.Crear_2.setObjectName("Crear_2")
        self.lineEdit = QtGui.QLineEdit(calendario)
        self.lineEdit.setGeometry(QtCore.QRect(90, 30, 241, 27))
        self.lineEdit.setObjectName("lineEdit")
        self.label = QtGui.QLabel(calendario)
        self.label.setGeometry(QtCore.QRect(10, 30, 66, 17))
        self.label.setObjectName("label")

        self.retranslateUi(calendario)
        QtCore.QMetaObject.connectSlotsByName(calendario)

    def retranslateUi(self, calendario):
        calendario.setWindowTitle(QtGui.QApplication.translate("calendario", "calendarioes", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("calendario", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear_2.setText(QtGui.QApplication.translate("calendario", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("calendario", "Nombre :", None, QtGui.QApplication.UnicodeUTF8))



