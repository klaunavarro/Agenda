#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
from editar_calendario import Ui_Calendario_editar

class Calendario_editar(QtGui.QDialog):

    def __init__(self):
        super(Calendario_editar, self).__init__()
        self.ui = Ui_Calendario_editar()
        self.ui.setupUi(self)
        #self.set_listeners()
        self.show()

        
   

