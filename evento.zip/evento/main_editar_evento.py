#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
from Editar_evento import Ui_editar_evento

class Evento_editar(QtGui.QDialog):

    def __init__(self):
        super(Evento_editar, self).__init__()
        self.ui = Ui_editar_evento()
        self.ui.setupUi(self)
        #self.set_listeners()
        self.show()

        
   

