#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
from Crear_evento import Ui_Crear_evento

class Evento_crear(QtGui.QDialog):

    def __init__(self):
        super(Evento_crear, self).__init__()
        self.ui = Ui_Crear_evento()
        self.ui.setupUi(self)
        #self.set_listeners()
        self.show()

        
   

