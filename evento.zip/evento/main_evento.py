#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import main_editar_evento
import main_crear_evento
from Evento import Ui_Evento

class Evento(QtGui.QDialog):

    def __init__(self):
        super(Evento, self).__init__()
        self.ui = Ui_Evento()
        self.ui.setupUi(self)
        self.set_listeners()
        self.show()

    def set_listeners(self):
        self.ui.Crear.clicked.connect(self.edit)
        #self.ui.Eliminar.clicked.connect(self.delete)
        self.ui.Editar.clicked.connect(self.create)
		
    def edit(self):
        form = main_crear_evento.Evento_crear()
        form.exec_()

    def create(self):
        form2 = main_editar_evento. Evento_editar()
        form2.exec_()


   
def run():
    app = QtGui.QApplication(sys.argv)
    ma = Evento()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run()
