#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import main_editar_evento
import main_crear_evento
import main_calendario
import controller1
from Evento import Ui_Evento

class Evento(QtGui.QDialog):

    def __init__(self):
        super(Evento, self).__init__()
        self.ui = Ui_Evento()
        self.ui.setupUi(self)
        self.listeners()
        self.cargar_eventos()
        self.show()

    def listeners(self):
        
        self.ui.Crear.clicked.connect(self.show_act)
        self.ui.Eliminar.clicked.connect(self.eliminar_evento)
        self.ui.Editar.clicked.connect(self.editar_eventos)
        self.ui.Btn_menu_1.clicked.connect(self.show_add2)
        self.ui.Salir.clicked.connect(self.cancel)
        self.ui.Btn_search.clicked.connect(self.buscar_eventos)
        
    def show_add2(self):
        form3 = main_calendario.Evento()
        form3.rejected.connect(self.cargar_eventos)
        form3.exec_()
		
    def edit(self):
        form = main_crear_evento.Evento_crear()
        form.exec_()
        
    def evento(self):
        form = main_calendario.Evento()
        form.exec_()

    def create(self):
        form2 = main_editar_evento. Evento_editar()
        form2.exec_()
     
    def cancel(self):
        self.reject()

	# Aca cargare los eventos en la grilla
    def cargar_eventos(self, eventos = None):
		if eventos is None:
			eventos = controller1.obtener_eventos()
		
		self.model = QtGui.QStandardItemModel(len(eventos),7)
		self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"ID"))
		self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Desde"))
		self.model.setHorizontalHeaderItem(2, QtGui.QStandardItem(u"Hasta"))
		self.model.setHorizontalHeaderItem(3, QtGui.QStandardItem(u"Calendario"))
		self.model.setHorizontalHeaderItem(4, QtGui.QStandardItem(u"Detalle"))
		self.model.setHorizontalHeaderItem(5, QtGui.QStandardItem(u"Lugar"))
		self.model.setHorizontalHeaderItem(6, QtGui.QStandardItem(u"Participantes"))
		
		
	
		# Se filtran los eventos de acuerdo al campo detalle 
		completer = QtGui.QCompleter(map(lambda c: c["Detalle"], eventos), self) 
		completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
		self.ui.Search_box.setCompleter(completer)
		#Relleno mi tabla con mis valores de la base de daros 
		
		r = 0
		for row in eventos:
			index = self.model.index(r, 0, QtCore.QModelIndex());
			self.model.setData(index, row['id_evento'])
			index = self.model.index(r, 1, QtCore.QModelIndex());
			self.model.setData(index, row['fecha_desde'])
			index = self.model.index(r, 2, QtCore.QModelIndex());
			self.model.setData(index, row['fecha_hasta'])
			index = self.model.index(r, 3, QtCore.QModelIndex());
			self.model.setData(index, row['nombre'])
			index = self.model.index(r, 4, QtCore.QModelIndex());
			self.model.setData(index, row['detalle'])
			index = self.model.index(r, 5, QtCore.QModelIndex());
			self.model.setData(index, row['lugar'])
			index = self.model.index(r, 6, QtCore.QModelIndex());
			self.model.setData(index, row['participantes'])
			r = r+1
		
		self.ui.tableView.setModel(self.model)
		#Con hideColumn ocultare la primera columna de la id para que no me aparezca cuando cargo los eventos
		self.ui.tableView.hideColumn(0)
		self.ui.tableView.setColumnWidth(1,150)
		self.ui.tableView.setColumnWidth(2,150)
		self.ui.tableView.setColumnWidth(3,100)
		self.ui.tableView.setColumnWidth(4,250)
		self.ui.tableView.setColumnWidth(5,250)
		self.ui.tableView.setColumnWidth(6,250)       
		
    def show_act(self):
		crear_evento = main_crear_evento.Evento_crear()
		crear_evento.rejected.connect(self.cargar_eventos)
		crear_evento.exec_()
        	
    def buscar_eventos(self):
		word = self.ui.Search_box.text()
		eventos = controller1.buscar_eventos(word)
		self.cargar_eventos(eventos)		
	
	# Metodo para borrar un evento de la grilla	
    def eliminar_evento(self):
		model = self.ui.tableView.model()
		index = self.ui.tableView.currentIndex()
		if index.row() == -1:
			self.errorMessageDialog = QtGui.QErrorMessage(self)
			self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
			return False
		else:
			id_evento = model.index(index.row(), 0, QtCore.QModelIndex()).data()
			self.cargar_eventos()
			msgBox = QtGui.QMessageBox()
			msgBox.setText("El registro fue eliminado.")
			msgBox.setInformativeText("Desea guardar los cambios?")
			msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Discard | QtGui.QMessageBox.Cancel)
			msgBox.setDefaultButton(QtGui.QMessageBox.Save)
			r = msgBox.exec_()
			if r == QtGui.QMessageBox.Save:
				controller1.delete(str(id_evento))
				self.cargar_eventos()
				return True
			else:
				self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
				self.ui.errorMessageDialog.showMessage(" El registro no fue eliminado")
				return False
				
	# Aca me aseguro de que el usuario seleccione una fila para editar			
    def editar_eventos(self):
		
		model = self.ui.tableView.model()
		index = self.ui.tableView.currentIndex()
		if index.row() == -1:
			self.errorMessageDialog = QtGui.QErrorMessage(self)
			self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
			return False
			
		else:
			
			evento = model.index(index.row(),1, QtCore.QModelIndex()).data()
			Editar_evento = main_editar_evento.Evento_editar(evento) 
			Editar_evento.rejected.connect(self.cargar_eventos) 
			Editar_evento.exec_()

    		
   
def run():
    app = QtGui.QApplication(sys.argv)
    ma = Evento()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run()
