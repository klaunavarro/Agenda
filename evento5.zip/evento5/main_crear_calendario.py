#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller 
from PySide import QtGui, QtCore
from Crear_calendario import Ui_crear_calendario

class Calendario_crear(QtGui.QDialog):

    def __init__(self):
        super(Calendario_crear, self).__init__()
        self.ui = Ui_crear_calendario()
        self.ui.setupUi(self)
        self.listeners()
        self.show()
        
    def listeners(self):
		    
        self.ui.Crear.clicked.connect(self.Agregar)
        self.ui.Crear_2.clicked.connect(self.cancel)
        
    def Agregar(self):
		nombre = self.ui.lineEdit.text()
		
		
		
		if nombre:
			resultado = controller.crear_calendario(nombre)
			
				
		else:
			self.errorMessageDialog = QtGui.QErrorMessage(self)
			self.errorMessageDialog.showMessage("Debe ingresar algo")
			return False
		
  
    
    
    
    def cancel(self):
        self.reject()
   

