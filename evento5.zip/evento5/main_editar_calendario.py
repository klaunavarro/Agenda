#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
import main_editar_calendario
import main_crear_calendario
from PySide import QtGui, QtCore
from editar_calendario import Ui_Calendario_editar

class Calendario_editar(QtGui.QDialog):

    def __init__(self, calendario=None):
        super(Calendario_editar, self).__init__()
        self.ui = Ui_Calendario_editar()
        self.ui.setupUi(self)
        self.show()
        
        self.calendario = calendario
        
        self.ui.lineEdit.setText(calendario)
        
        self.ui.Crear.clicked.connect(self.editar)
        self.ui.Crear_2.clicked.connect(self.cancel)

    def editar(self):
		id_cal = controller.obtener_id(self.calendario)
		for id_ca in id_cal:
			id_ = id_ca[0]
			
		id__ = id_
		# saco el valor del linedit
		
		nombre = self.ui.lineEdit.text()
		
		if nombre:
			resultado = controller.editar_cal(id__, nombre)
				
		else:
			self.errorMessageDialog = QtGui.QErrorMessage(self)
			self.errorMessageDialog.showMessage("Debe ingresar algo")
			return False
		
		if (nombre == self.calendario):
			self.errorMessageDialog = QtGui.QErrorMessage(self)
			self.errorMessageDialog.showMessage(u"No realizo ningún cambio")
			return False
			

		#calendarios = None
		#if calendarios is None:
		#	calendarios = controller.obtener_calendarios()
		#r = 0
		#for row in calendarios:
			
		#	index = self.model.index(r, 0, QtCore.QModelIndex())
		#	nombres=self.model.setData(index, row['Nombre'])
		#	if (nombre == nombres):
		#		self.errorMessageDialog = QtGui.QErrorMessage(self)
		#		self.errorMessageDialog.showMessage(u"No realizo ningún cambio pues nombre ya existe")
		#		return False
		#	r = r+1
				
		
    def cancel(self):
		self.reject()
		
		
		
		
